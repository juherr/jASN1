/*
* Copyright 2006 Abdulla G. Abdurakhmanov (abdulla.abdurakhmanov@gmail.com).
* 
* Licensed under the LGPL, Version 2 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
* 
*      http://www.gnu.org/copyleft/lgpl.html
* 
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
* 
* With any your questions welcome to my e-mail 
* or blog at http://abdulla-a.blogspot.com.
*/
using System;
using org.lineargs;
using org.lineargs.constraints;
using System.Collections.Generic;

namespace test.org.lineargs
{
	
	public class MyArguments
	{        
        private string stringParam;

        [Option(Name = "--str", ShortName = "-s", Description = "This is simple string value")]
        public string StringParam
        {
            get { return stringParam; }
            set { stringParam = value; }
        }
        
        private int intParam;

        [Option(Name = "--int", ShortName = "-i", Description = "This is simple int value")]
        public int IntParam
        {
            get { return intParam; }
            set { intParam = value; }
        }
                
        private bool boolParam;

        [Option(Name = "--bool", ShortName = "-b", Description = "This is simple bool value")]
        public bool BoolParam
        {
            get { return boolParam; }
            set { boolParam = value; }
        }

        private object otherField1;

        public object OtherField1
        {
            get { return otherField1; }
            set { otherField1 = value; }
        }
                
        private ICollection<string> listParams;

        [ListOption(Name = "--list", ShortName = "-l", Description = "This is simple list value")]
        public ICollection<string> ListParams
        {
            get { return listParams; }
            set { listParams = value; }
        }

        private Object otherField2;

        public Object OtherField2
        {
            get { return otherField2; }
            set { otherField2 = value; }
        }
        
        private String stringParam2;

        [Option(Name = "--str2", ShortName = "-s2", IsOptional = true, Description = "This is simple optional string value")]
        public String StringParam2
        {
            get { return stringParam2; }
            set { stringParam2 = value; }
        }

	}
}