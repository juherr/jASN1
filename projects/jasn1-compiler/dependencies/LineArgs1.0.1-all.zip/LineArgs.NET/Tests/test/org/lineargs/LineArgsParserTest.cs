/*
* Copyright 2006 Abdulla G. Abdurakhmanov (abdulla.abdurakhmanov@gmail.com).
* 
* Licensed under the LGPL, Version 2 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
* 
*      http://www.gnu.org/copyleft/lgpl.html
* 
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
* 
* With any your questions welcome to my e-mail 
* or blog at http://abdulla-a.blogspot.com.
*/
using System;
using org.lineargs;
using csUnit;

namespace test.org.lineargs
{
	[TestFixture]
	public class LineArgsParserTest
	{
	
		[Test]
		public virtual void  testParse()
		{
			LineArgsParser parser = new LineArgsParser();
			string[] args = new string[]{"-s", "test", "--bool", "--list", "aa;dd;nnn", "-i", "10"};
			MyArguments arguments = parser.parse<MyArguments>(args);
			Assert.Equals(arguments.StringParam, "test");
			Assert.Equals(arguments.IntParam, 10);
			Assert.Equals(arguments.BoolParam, true);
			Assert.Equals(arguments.ListParams.Count, 3);
			Assert.Null(arguments.StringParam2);
            System.IO.TextWriter writer = new System.IO.StringWriter();
            parser.printHelp<MyArguments>(writer);
		}
		
        [Test]
		public virtual void  testFails()
		{
			LineArgsParser parser = new LineArgsParser();
			
			string[] args = {"-s", "test", "-i", "10", "--list", "aa;dd;nnn"};
			try
			{
				parser.parse<MyArguments>(args);
				Assert.True(false);
			}
			catch (Exception ex)
			{
				if (!ex.ToString().Contains("Unable to present value for mandatory option"))
				{
					throw ex;
				}
			}
		}

        [Test]
        public virtual void testUnknownOption()
        {
            LineArgsParser parser = new LineArgsParser();

            string[] args = { "-s", "test", "-i", "10", "-unknown", "--list", "aa;dd;nnn" };
            try
            {
                parser.parse<MyArguments>(args);
                Assert.True(false);
            }
            catch (Exception ex)
            {
                if (!ex.ToString().Contains("Unknown"))
                {
                    throw ex;
                }
            }
        }

	}
}