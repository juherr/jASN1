﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("LineArgs.NET")]
[assembly: AssemblyDescription("The command line argument parser library")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Abdulla G. Abdurakhmanov")]
[assembly: AssemblyProduct("LineArgs")]
[assembly: AssemblyCopyright("Copyright © Abdulla G. Abdurakhmanov")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("aecd2dcb-3671-4049-85f4-f0de17344a4d")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.0.1")]
[assembly: AssemblyFileVersion("1.0.1")]
