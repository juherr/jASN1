/*
 * Copyright 2006 Abdulla G. Abdurakhmanov (abdulla.abdurakhmanov@gmail.com).
 * 
 * Licensed under the LGPL, Version 2 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.gnu.org/copyleft/lgpl.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * With any your questions welcome to my e-mail 
 * or blog at http://abdulla-a.blogspot.com.
 */
package test.org.lineargs;

import java.util.Collection;
import org.lineargs.*;
import org.lineargs.constraints.*;

public class MyArguments {
        
    @Option ( name = "--str", shortName="-s", description="This is simple string value" )
    private String stringParam;
    
    @Option ( name = "--int", shortName="-i", description="This is simple int value" )
    private Integer intParam;
    
    @Option ( name = "--bool", shortName="-b", description="This is simple bool value" )
    private Boolean boolParam;
    private Object otherField1;
    
    @ListOption ( name = "--list", shortName="-l", description="This is simple list value" )
    private Collection<String> listParam;
    
    private Object otherField2;

    @Option ( name = "--str2", shortName="-s2", isOptional = true, description="This is simple optional string value" )
    private String stringParam2;

    public String getStringParam() {
        return stringParam;
    }

    public void setStringParam(String stringParam) {
        this.stringParam = stringParam;
    }

    public Integer getIntParam() {
        return intParam;
    }

    public void setIntParam(Integer intParam) {
        this.intParam = intParam;
    }

    public Boolean getBoolParam() {
        return boolParam;
    }

    public void setBoolParam(Boolean boolParam) {
        this.boolParam = boolParam;
    }

    public Collection<String> getListParam() {
        return listParam;
    }

    public void setListParam(Collection<String> listParam) {
        this.listParam = listParam;
    }

    public String getStringParam2() {
        return stringParam2;
    }

    public void setStringParam2(String stringParam2) {
        this.stringParam2 = stringParam2;
    }
}
