/*
 * Copyright 2006 Abdulla G. Abdurakhmanov (abdulla.abdurakhmanov@gmail.com).
 * 
 * Licensed under the LGPL, Version 2 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.gnu.org/copyleft/lgpl.html
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * With any your questions welcome to my e-mail 
 * or blog at http://abdulla-a.blogspot.com.
 */
package test.org.lineargs;

import java.util.Collection;

import junit.framework.TestCase;

import org.lineargs.LineArgsParser;

public class LineArgsParserTest extends TestCase {
    public LineArgsParserTest(String sTestName) {
        super(sTestName);
    }
    

    /**
     * @see LineArgsParser#parse(Class,String[])
     */
    public void testParse() throws Exception {
        LineArgsParser parser = new LineArgsParser();
        String args[] = new String[] {
            "-s","test",
            "--bool",
            "--list","aa;dd;nnn",
             "-i","10"            
        };
        MyArguments arguments =  parser.parse(MyArguments.class,args);
        assertEquals(arguments.getStringParam(),"test");
        assertEquals(arguments.getIntParam().intValue(),10);
        assertEquals(arguments.getBoolParam().booleanValue(),true);
        assertEquals(arguments.getListParam().size(),3);
        assertNull(arguments.getStringParam2());
        parser.printHelp(MyArguments.class,System.out);
    }
    
    public void testFails() throws Exception {
        LineArgsParser parser = new LineArgsParser();
    
        String args[] = new String[] {
            "-s","test",
            "-i","10",
            "--list","aa;dd;nnn"
        };
        try {
           parser.parse(MyArguments.class,args);
           assertTrue(false);
        }
        catch(Exception ex) {
            if(!ex.toString().contains("Unable to present value for mandatory option")) {
                throw ex;
            }
        }
    }
    
    public void testUnknownOption() throws Exception {
        LineArgsParser parser = new LineArgsParser();
    
        String args[] = new String[] {
            "-s","test",
            "-i","10",
            "-unknown",
            "--list","aa;dd;nnn"
        };
        try {
           parser.parse(MyArguments.class,args);
           assertTrue(false);
        }
        catch(Exception ex) {
            if(!ex.toString().contains("Unknown")) {
                throw ex;
            }
        }
    }
    
}
